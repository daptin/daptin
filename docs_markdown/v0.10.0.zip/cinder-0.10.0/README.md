<a href="http://sourcefoundry.org/cinder/"><img src="img/header.png" alt="Cinder | A clean, responsive theme for MkDocs" width="728"></a>

## Cinder

A clean, responsive MkDocs static documentation site generator theme

[Demo and Documentation](http://sourcefoundry.org/cinder/)

